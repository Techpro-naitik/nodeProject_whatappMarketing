module.exports = (sequelize, Sequelize) => {
    const messagequeueModel = sequelize.define("message_queue", {
        message_id: {
            type: Sequelize.INTEGER
        },
        contact_id: {
            type: Sequelize.INTEGER
        },
        time_to_send: {
            type: Sequelize.DATE
        },
        status: {
            type: Sequelize.INTEGER
        }
    });

    return messagequeueModel;
};