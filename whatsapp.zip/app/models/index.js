const dbConfig = require("../config/db.config.js");

const Sequelize = require("sequelize");
const sequelize = new Sequelize(dbConfig.DB, dbConfig.USER, dbConfig.PASSWORD, {
  host: dbConfig.HOST,
  dialect: dbConfig.dialect,
  operatorsAliases: false,

  pool: {
    max: dbConfig.pool.max,
    min: dbConfig.pool.min,
    acquire: dbConfig.pool.acquire,
    idle: dbConfig.pool.idle
  }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.addressBook = require("./address_book.model.js")(sequelize, Sequelize);
db.messageDetail = require("./message_detail.model.js")(sequelize, Sequelize);
db.messageAttachment = require("./message_attachment.model.js")(sequelize, Sequelize);
db.messageScheduling = require("./message_scheduling.model.js")(sequelize, Sequelize);
db.messageQueue = require("./message_queue.model.js")(sequelize, Sequelize);

db.messageDetail.hasMany(db.messageAttachment, {foreignKey: 'message_id'});
module.exports = db;