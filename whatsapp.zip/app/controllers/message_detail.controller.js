const db = require("../models");
const messageDetail = db.messageDetail;
const messageAttachment = db.messageAttachment;
const Op = db.Sequelize.Op;
const { validationResult } = require("express-validator");
const fs = require("fs");

// Create and Save a new Message
exports.create = (req, res) => {
  const errors = validationResult(req.body);
  if (!errors.isEmpty()) {
    return res.status(201).json({ errors: errors.array() });
  }

  const message = req.body;

  // Save Message in the database
  messageDetail
    .create(message)
    .then((data) => {
      let docArray = [];
      if (req.files) {
        req.files.forEach((element) => {
          docArray.push({
            message_id: data.id,
            attachment: "uploads/" + element.filename,
            directorypath: element.path,
          });
        });
        messageAttachment
          .bulkCreate(docArray)
          .then((resp) => {
            data.dataValues.message_attachments = resp;
            res.send(data);
          })
          .catch((err) => {
            res.status(500).send({
              message:
                err.message ||
                "Some error occurred while creating the Message template.",
            });
          });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while creating the Message template.",
      });
    });
};

// Retrieve all Message from the database.
exports.findAll = (req, res) => {
  messageDetail
    .findAll({
      where: {
        status: 1,
      },
      order: [["id", "ASC"]],
      include: [
        {
          model: messageAttachment,
          required: false,
        },
      ],
    })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message ||
          "Some error occurred while retrieving Message templates.",
      });
    });
};

// Find a single Message with an id
exports.findOne = (req, res) => {
  const id = req.params.id;

  messageDetail
    .findByPk(id, {
      include: [
        {
          model: messageAttachment,
          required: false,
        },
      ],
    })
    .then((data) => {
      if (data === null) {
        res.status(201).send({
          message: "Some error occurred while retrieving Message template.",
        });
      } else {
        res.send(data);
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error retrieving Message template with id=" + id,
      });
    });
};

// Update a Message by the id in the request
exports.update = (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(201).json({ errors: errors.array() });
  }
  const id = req.params.id;

  messageDetail
    .update(req.body, {
      where: { id: id },
    })
    .then((num) => {
      if (num == 1) {
        let docArray = [];
        if (req.files) {
          req.files.forEach((element) => {
            docArray.push({
              message_id: id,
              attachment: "uploads/" + element.filename,
              directorypath: element.path,
            });
          });
          messageAttachment
            .bulkCreate(docArray) 
            .then((resp) => {
              res.send({
                message: "Message template was updated successfully.",
              });
            })
            .catch((err) => { 
              res.status(500).send({ 
                message:
                  err.message ||
                  "Some error occurred while updating the Message template.",
              });
            });
        } else{
          res.send({
            message: "Message template was updated successfully.",
          });
        }
      } else {
        res.send({
          message: `Cannot update Message template. Maybe Message template was not found or request is empty!`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating Message",
      });
    });
};

//Delete Message Attachment
exports.delete = (req, res) => {
  const id = req.body.id;
  messageAttachment
    .findAll({
      where: { id: id },
    })
    .then((data) => {
      messageAttachment
        .destroy({
          where: { id: id },
        })
        .then((num) => {
          if (num >= 1) {
            data.forEach((element) => {
              fs.unlink(element.directorypath, (err) => {
                if (err) {
                  console.log("failed to delete local image:" + err);
                } else {
                  console.log("successfully deleted local image");
                }
              });
            });
            res.send({
              message: "Attachments were deleted successfully!",
            });
          } else {
            res.send({
              message: `Cannot delete Attachment. Maybe Attachment was not found!`,
            });
          }
        })
        .catch((err) => {
          res.status(500).send({
            message: "Could not delete Attachment",
          });
        });
    })
    .catch((err) => {});
};
