// module.exports = {
//   HOST: "localhost",
//   USER: "sanjeev",
//   PASSWORD: "jobseeder@123",
//   DB: "whatsapp",
//   dialect: "postgres",
//   pool: {
//     max: 5,
//     min: 0,
//     acquire: 30000,
//     idle: 10000
//   }
// };
module.exports = {
  HOST: "whatsapppostgres.postgres.database.azure.com",
  USER: "shakti@whatsapppostgres",
  PASSWORD: "Admin@1234",
  DB: "whatsapp",
  dialect: "postgres",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};